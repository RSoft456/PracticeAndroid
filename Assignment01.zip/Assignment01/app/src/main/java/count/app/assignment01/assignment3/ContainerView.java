package count.app.assignment01.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import count.app.assignment01.R;

public class ContainerView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container_view);
    }
}