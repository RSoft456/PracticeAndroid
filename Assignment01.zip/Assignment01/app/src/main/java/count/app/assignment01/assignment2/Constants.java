package count.app.assignment01.assignment2;

public class Constants {
    static String name = "xyz";
    static String password = "1234";
    static String phone = "123456789";
    static String Email = "xyz@gmail.com";
    static String Gender = "Female";
    static String Department = "Android";
    public static String firstTeacherName="Kashif";
    public static String firstTeacherpassowrd="kashif123";
    public static String firstTeacheremail="muhammadkashif@gmail.com";
    public static String secondTeacherName="Shahkar";
    public static String secondTeacherpassowrd="shahkar123";
    public static String secondTeacheremail="shahkar.raza@gmail.com";

    public static String studentName="";
    public static String studentPassowrd="";
    public static String studentEmail="";
    public static String studentphone="";

}
