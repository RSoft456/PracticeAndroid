package count.app.assignment01.lab04;

public interface StudentInterface {
    public void setStudentOnclick();
}
